import React, { useEffect, useMemo, useState } from 'react'
import { Briefcase, MapPin, Heart, HeartOff, Search, Filter, X, ExternalLink, Building2, Calendar, Clock, DollarSign, ArrowUpDown, Star, Info } from 'lucide-react'
const APP_NAME = 'Emprego PMZ'
const MOCK_JOBS = [
  { id:'1', title:'Agente de Atendimento ao Cliente', company:'Ribeirinho Telecom', city:'Porto de Moz', state:'PA', remote:false, postedAt:new Date(Date.now()-2*864e5).toISOString(), type:'Tempo Integral', salaryRange:'R$2.200–R$2.800', description:'Atendimento presencial e telefônico, abertura de chamados e apoio ao time técnico.', applyUrl:'https://example.com/vaga/1', source:'MockDB', tags:['Atendimento','Suporte','Operacional'] },
  { id:'2', title:'Assistente Administrativo', company:'Cooperativa Verde', city:'Porto de Moz', state:'PA', remote:false, postedAt:new Date(Date.now()-6*864e5).toISOString(), type:'Tempo Integral', salaryRange:'R$2.000–R$2.600', description:'Rotinas administrativas, notas, planilhas, atendimento. Conhecimento em Excel.', applyUrl:'https://example.com/vaga/2', source:'MockDB', tags:['Administração','Backoffice'] },
]
const FAVORITES_KEY = 'emprego_pmz_favorites'
const loadFavorites = () => { try { return JSON.parse(localStorage.getItem(FAVORITES_KEY)) || {} } catch { return {} } }
const saveFavorites = (fav) => localStorage.setItem(FAVORITES_KEY, JSON.stringify(fav))
const formatDate = (iso) => new Date(iso).toLocaleDateString('pt-BR', { day:'2-digit', month:'short' })
async function fetchJobs({ city, query = '', type = '', sort = 'recent' }) {
  let data = MOCK_JOBS.filter(j => j.city.toLowerCase() === city.toLowerCase())
  if (query) { const q = query.toLowerCase(); data = data.filter(j => j.title.toLowerCase().includes(q) || j.company.toLowerCase().includes(q) || j.tags.join(' ').toLowerCase().includes(q) || j.description.toLowerCase().includes(q)) }
  if (type) data = data.filter(j => j.type === type)
  switch (sort) { case 'title': data.sort((a,b)=>a.title.localeCompare(b.title)); break; case 'company': data.sort((a,b)=>a.company.localeCompare(b.company)); break; default: data.sort((a,b)=>+new Date(b.postedAt)-+new Date(a.postedAt)) }
  await new Promise(r=>setTimeout(r,200)); return data
}
function Badge({ children }) { return <span className='inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-medium'>{children}</span> }
function JobCard({ job, favorite, onToggleFavorite, onOpen }) {
  return (<div className='rounded-2xl border shadow-sm p-4 hover:shadow-md transition'>
    <div className='flex items-start gap-3'>
      <div className='p-3 rounded-xl bg-gray-50'><Briefcase className='h-5 w-5' /></div>
      <div className='flex-1'>
        <div className='flex items-start justify-between'>
          <div>
            <h3 className='text-lg font-semibold leading-tight'>{job.title}</h3>
            <div className='mt-1 text-sm text-gray-600 flex items-center gap-1'><Building2 className='h-4 w-4' /><span>{job.company}</span></div>
            <div className='mt-1 text-sm text-gray-600 flex items-center gap-1'><MapPin className='h-4 w-4' /><span>{job.city}, {job.state}</span></div>
          </div>
          <button className='p-2 rounded-full hover:bg-gray-100' onClick={() => onToggleFavorite(job.id)}>{favorite ? <Heart className='h-5 w-5' /> : <HeartOff className='h-5 w-5' />}</button>
        </div>
        <div className='mt-3 flex flex-wrap items-center gap-2'>
          <Badge><Calendar className='h-3.5 w-3.5 mr-1' /> Publicada {formatDate(job.postedAt)}</Badge>
          <Badge><Clock className='h-3.5 w-3.5 mr-1' /> {job.type}</Badge>
          {job.salaryRange && <Badge><DollarSign className='h-3.5 w-3.5 mr-1' /> {job.salaryRange}</Badge>}
          {job.source && <Badge><Star className='h-3.5 w-3.5 mr-1' /> {job.source}</Badge>}
        </div>
        <p className='mt-3 text-sm text-gray-700'>{job.description}</p>
        <div className='mt-4 flex items-center gap-2'>
          <button className='rounded-xl px-3 py-2 text-sm border hover:bg-gray-50' onClick={() => onOpen(job)}>Ver detalhes</button>
          {job.applyUrl && <a className='rounded-xl px-3 py-2 text-sm border hover:bg-gray-50 inline-flex items-center gap-1' href={job.applyUrl} target='_blank' rel='noreferrer'>Candidatar-se <ExternalLink className='h-4 w-4' /></a>}
        </div>
      </div>
    </div>
  </div>)}
function DetailsModal({ job, onClose }) {
  if (!job) return null
  return (<div className='fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4' role='dialog' aria-modal>
    <div className='bg-white rounded-2xl w-full max-w-2xl p-6 shadow-xl'>
      <div className='flex items-start justify-between'>
        <div>
          <h2 className='text-xl font-semibold'>{job.title}</h2>
          <p className='text-gray-600 mt-1 flex items-center gap-1'><Building2 className='h-4 w-4' /> {job.company}</p>
          <p className='text-gray-600 mt-1 flex items-center gap-1'><MapPin className='h-4 w-4' /> {job.city}, {job.state}</p>
        </div>
        <button className='p-2 rounded-full hover:bg-gray-100' onClick={onClose} aria-label='Fechar'><X className='h-5 w-5' /></button>
      </div>
      <div className='mt-4 flex flex-wrap gap-2'>
        <Badge><Calendar className='h-3.5 w-3.5 mr-1' /> Publicada {formatDate(job.postedAt)}</Badge>
        <Badge><Clock className='h-3.5 w-3.5 mr-1' /> {job.type}</Badge>
        {job.salaryRange && <Badge><DollarSign className='h-3.5 w-3.5 mr-1' /> {job.salaryRange}</Badge>}
        {job.tags?.map(t => <Badge key={t}>{t}</Badge>)}
      </div>
      <p className='mt-4 whitespace-pre-line leading-relaxed'>{job.description}</p>
      <div className='mt-6 flex items-center gap-2'>
        {job.applyUrl && <a className='rounded-xl px-3 py-2 text-sm border hover:bg-gray-50 inline-flex items-center gap-1' href={job.applyUrl} target='_blank' rel='noreferrer'>Candidatar-se <ExternalLink className='h-4 w-4' /></a>}
        <button className='rounded-xl px-3 py-2 text-sm border hover:bg-gray-50 inline-flex items-center gap-1' onClick={onClose}>Fechar</button>
      </div>
    </div>
  </div>)}
export default function App() {
  const CITY = 'Porto de Moz'
  const [query, setQuery] = useState('')
  const [type, setType] = useState('')
  const [sort, setSort] = useState('recent')
  const [jobs, setJobs] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [favorites, setFavorites] = useState({})
  const [selected, setSelected] = useState(null)
  useEffect(() => { setFavorites(loadFavorites()) }, [])
  useEffect(() => { localStorage && saveFavorites(favorites) }, [favorites])
  const favoriteJobs = useMemo(() => jobs.filter(j => favorites[j.id]), [jobs, favorites])
  const runSearch = async () => { try { setLoading(true); setError(null); const res = await fetchJobs({ city: CITY, query, type, sort }); setJobs(res) } catch(e){ setError('Erro.') } finally { setLoading(false) } }
  useEffect(() => { runSearch() }, [type, sort])
  const toggleFavorite = (id) => setFavorites(prev => ({ ...prev, [id]: !prev[id] }))
  return (<div className='min-h-screen bg-gradient-to-b from-white to-gray-50'>
    <header className='px-4 sm:px-6 lg:px-8 py-6 border-b bg-white/70 backdrop-blur sticky top-0 z-40'>
      <div className='max-w-6xl mx-auto flex flex-col gap-4 md:flex-row md:items-center md:justify-between'>
        <div className='flex items-center gap-3'>
          <div className='p-2 rounded-2xl bg-gray-100'><Briefcase className='h-5 w-5' /></div>
          <div><h1 className='text-xl font-bold'>{APP_NAME}</h1><p className='text-sm text-gray-600'>Busque vagas locais, salve favoritas e candidate-se rápido.</p></div>
        </div>
        <div className='flex gap-2'><a href='#como-integrar' className='text-sm inline-flex items-center gap-1 rounded-xl border px-3 py-2 hover:bg-gray-50'><Info className='h-4 w-4' /> Como integrar a APIs</a></div>
      </div>
    </header>
    <main className='max-w-6xl mx-auto p-4 sm:p-6 lg:p-8'>
      <div className='rounded-2xl border bg-white p-4 shadow-sm'>
        <div className='flex flex-col gap-3 md:flex-row md:items-center'>
          <div className='flex-1 relative'>
            <Search className='h-4 w-4 absolute left-3 top-3' />
            <input value={query} onChange={(e)=>setQuery(e.target.value)} onKeyDown={(e)=>e.key==='Enter' && runSearch()} placeholder='Pesquisar por cargo, empresa, palavra-chave...' className='w-full pl-9 pr-3 py-2 rounded-xl border focus:outline-none focus:ring-2' />
          </div>
          <button onClick={runSearch} className='rounded-xl border px-3 py-2 inline-flex items-center gap-2 hover:bg-gray-50'><Filter className='h-4 w-4' /> Buscar</button>
          <div className='flex items-center gap-2'>
            <select className='rounded-xl border px-3 py-2' value={type} onChange={(e)=>setType(e.target.value)}>
              <option value=''>Tipo de vaga</option><option>Tempo Integral</option><option>Meio Período</option><option>Freelancer</option><option>Estágio</option>
            </select>
            <select className='rounded-xl border px-3 py-2' value={sort} onChange={(e)=>setSort(e.target.value)}>
              <option value='recent'>Mais recentes</option><option value='title'>Título (A→Z)</option><option value='company'>Empresa (A→Z)</option>
            </select>
            <span className='inline-flex items-center gap-1 text-sm text-gray-600'><ArrowUpDown className='h-4 w-4' /> Ordenar</span>
          </div>
        </div>
      </div>
      <div className='mt-6 grid grid-cols-1 md:grid-cols-2 gap-4'>
        {loading && <div className='col-span-full text-center py-10 text-gray-600'>Carregando vagas...</div>}
        {!loading && jobs.length === 0 && <div className='col-span-full text-center py-10 text-gray-600'>Nenhuma vaga encontrada.</div>}
        {!loading && jobs.map(job => <JobCard key={job.id} job={job} favorite={!!favorites[job.id]} onToggleFavorite={toggleFavorite} onOpen={setSelected} />)}
      </div>
      <section className='mt-10'><h2 className='text-lg font-semibold mb-3 flex items-center gap-2'><Heart className='h-5 w-5' /> Favoritas ({favoriteJobs.length})</h2>
        {favoriteJobs.length === 0 ? <p className='text-sm text-gray-600'>Você ainda não salvou nenhuma vaga.</p> :
          <div className='grid grid-cols-1 md:grid-cols-2 gap-4'>{favoriteJobs.map(job => <JobCard key={job.id} job={job} favorite={!!favorites[job.id]} onToggleFavorite={toggleFavorite} onOpen={setSelected} />)}</div>}
      </section>
      <section id='como-integrar' className='mt-12'><h2 className='text-lg font-semibold mb-2'>Integração com fontes reais de vagas</h2><div className='prose prose-sm max-w-none'><p>Este app usa dados fictícios (MOCK_JOBS). Para conectar a uma API, substitua <code>fetchJobs()</code>.</p></div></section>
    </main>
    <footer className='max-w-6xl mx-auto p-6 text-center text-xs text-gray-500'>Feito com ❤️ para Porto de Moz — {APP_NAME}</footer>
    <DetailsModal job={selected} onClose={()=>setSelected(null)} />
  </div>)}
