import { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = { appId: 'com.seunome.empregopmz', appName: 'Emprego PMZ', webDir: 'dist', server: { androidScheme: 'https' } };
export default config;