# Emprego PMZ — APK Rápido (Capacitor)

## Passo Único (modo turbo)
1. Instale **Android Studio** (SDK e JDK 17).
2. No terminal, dentro do projeto:
   ```bash
   npm install
   npm run build
   npm run cap:init     # cria config se não existir (usa appId com.seunome.empregopmz)
   npm run cap:add      # adiciona Android (só uma vez)
   npm run cap:copy
   npm run android      # abre o Android Studio
   ```
3. No Android Studio: **Build > Generate Signed Bundle / APK... > APK > Release** e finalize. O APK sai em `android/app/release/app-release.apk`.

> Dica: `vite.config.js` já tem `base: './'` (evita tela branca).

### Atualizar depois
```bash
npm run build && npm run cap:copy && npm run android
```

### Trocar o ID do app
Edite `capacitor.config.ts` (campo `appId`) **antes** do `npm run cap:init`.
